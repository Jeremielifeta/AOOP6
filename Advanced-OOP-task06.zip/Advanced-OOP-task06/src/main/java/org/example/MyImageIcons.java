package org.example;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class MyImageIcons extends JFrame{
    //declaration of different variables
    JFrame frame;
    JPanel panel;
    private JTextField searchBar;
    JButton button;
    JTextArea description;
    JPanel cardLayout01, cardLayout02, cardLayout03, cardLayout04, cardLayout05, cardLayout06, cardLayout07, cardLayout08;
    JLabel labeltitle,imagePath;
    ImageIcon icon;

    //constructor
    public MyImageIcons(){
        this.createFrame();
    }

    //method to create frame
    public JFrame createFrame() {
        //setting look and feel
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame = new JFrame("Image Icons");
        frame.setLayout(new BorderLayout());
        frame.setSize(900, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //adding components to frame
        JScrollPane scrollPane = new JScrollPane(this.createPanel());
        frame.add(this.createSearchBar(), BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);

        return frame;

    }

    //method to create search bar
    public JTextField createSearchBar(){
        //creating search bar
        searchBar = new JTextField("Search...");
        searchBar.setToolTipText("Search items...");

        //adding document listener to search bar
        searchBar.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                filterCards();
            }
            public void removeUpdate(DocumentEvent e) {
                filterCards();
            }
            public void changedUpdate(DocumentEvent e) {
                filterCards();
            }

            private void filterCards() {
                String text = searchBar.getText().toLowerCase();
                cardLayout01.setVisible("280 sl".contains(text));
                cardLayout02.setVisible("190 sl".contains(text));
                cardLayout03.setVisible("300 sl".contains(text));
                cardLayout04.setVisible("350 sl".contains(text));
                cardLayout05.setVisible("1998 500 sl".contains(text));
                cardLayout06.setVisible("500 sl".contains(text));
                cardLayout07.setVisible("sl-r231".contains(text));
                cardLayout08.setVisible("amg sl 63".contains(text));
                panel.revalidate();
                panel.repaint();
            }
        });

        return searchBar;
    }
    //method to create panel
    public JPanel createPanel(){
        //creating panel
        panel = new JPanel();
        panel.setLayout(new GridLayout(0,4,10,10));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        //adding card layouts to panel
        panel.add(createCardLayoutOne());
        panel.add(createCardLayoutTwo());
        panel.add(createCardLayoutThree());
        panel.add(createCardLayoutFour());
        panel.add(createCardLayoutFive());
        panel.add(createCardLayoutSix());
        panel.add(createCardLayoutSeven());
        panel.add(createCardLayoutEight());

        return panel;
    }

    // Helper methods for reusable components
    public JPanel createCardPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setPreferredSize(new Dimension(200, 300));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        return panel;
    }
    //method to create description area
    public JTextArea createDescription(String text) {
        JTextArea desc = new JTextArea();
        desc.setText(text);
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setEditable(false);
        desc.setOpaque(false);
        return desc;
    }
    //method to create south panel
    public JPanel createSouthPanel(JLabel image, JButton button) {
        JPanel southPanel = new JPanel();
        southPanel.setLayout(new BoxLayout(southPanel, BoxLayout.Y_AXIS));
        southPanel.setBackground(Color.LIGHT_GRAY);
        southPanel.add(image);
        southPanel.add(button);
        return southPanel;
    }
    //method to create card layout one
    public JPanel createCardLayoutOne() {
        //creating card layout one
        cardLayout01 = createCardPanel();

        //adding components to card layout one
        labeltitle = new JLabel("280 SL",JLabel.CENTER);
        labeltitle.setFont(new Font("Arial", Font.BOLD, 14));

        //description
        description = createDescription("The Mercedes-Benz 280 SL (W113) is a two-door luxury roadster produced from 1967 to 1971. Known as the Pagoda due to its concave roofline, it blended performance with refined design ");

        //image icon
         icon = new ImageIcon("src/main/images/SL 280.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);

        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout01, "The Mercedes-Benz 280 SL (W113) is a two-door luxury roadster produced from 1967 to 1971." +
                    "\n Known as the Pagoda due to its concave roofline, it blended performance with refined design\n" +
                    " ", "280 SL", JOptionPane.INFORMATION_MESSAGE);
        });
        //south panel
        JPanel southPanel = createSouthPanel(imagePath, button);

        cardLayout01.add(labeltitle, BorderLayout.NORTH);
        cardLayout01.add(description, BorderLayout.CENTER);
        cardLayout01.add(southPanel, BorderLayout.SOUTH);

        //mouse listener for hover effect
        cardLayout01.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout01.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout01.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout01;
    }

    //method to create card layout two
    public JPanel createCardLayoutTwo() {
        //creating card layout two
        cardLayout02 = createCardPanel();

        //adding components to card layout two
        labeltitle = new JLabel("190 SL",JLabel.CENTER);
        labeltitle.setFont(new Font("Arial", Font.BOLD, 14));

        description = createDescription("Nicknamed The Boulevardier, this elegant roadster was designed for stylish cruising rather than racing. ");

        icon = new ImageIcon("src/main/images/SL190.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);

        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout02, "A stylish two-door roadster with a 1.9L inline-4 engine, known for its elegant design and relaxed driving." +
                    "\n price: $80,000–$150,000\n" +
                    " ", "190 SL", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel southPanel = createSouthPanel(imagePath, button);

        cardLayout02.add(labeltitle, BorderLayout.NORTH);
        cardLayout02.add(description, BorderLayout.CENTER);
        cardLayout02.add(southPanel, BorderLayout.SOUTH);

        cardLayout02.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout02.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout02.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout02;
    }

    //method to create card layout three
    public JPanel createCardLayoutThree() {
        //creating card layout three
        cardLayout03 = createCardPanel();

        //adding components to card layout three
        labeltitle = new JLabel(" 300 SL",JLabel.CENTER);
        labeltitle.setFont(new Font("Arial", Font.BOLD, 14));

        description = createDescription("The original SL and a motorsport legend, famous for its upward-opening doors and fuel injection.");

         icon = new ImageIcon("src/main/images/SL 300.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);

        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout03, "Legendary coupe with gullwing doors and fuel-injected 3.0L inline-6. A motorsport icon." +
                    "\n Price: $1.6M–$2M+\n" +
                    " ", "300 SL", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel southPanel = createSouthPanel(imagePath, button);

        cardLayout03.add(labeltitle, BorderLayout.NORTH);
        cardLayout03.add(description, BorderLayout.CENTER);
        cardLayout03.add(southPanel, BorderLayout.SOUTH);

        cardLayout03.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout03.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout03.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout03;
    }
    //method to create card layout four
    public JPanel createCardLayoutFour() {
        //creating card layout four
        cardLayout04 = createCardPanel();

        //adding components to card layout four
        labeltitle = new JLabel("350 SL",JLabel.CENTER);
        labeltitle.setBounds(50, 10, 300, 30);

        description = createDescription("A long-running model with V8 power and classic styling, often seen in 1980s pop culture.");

        icon = new ImageIcon("src/main/images/Sl 350.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);

        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout04, "Top-tier R107 model with a 5.6L V8, automatic transmission, and luxury features." +
                    "\n Price: $30,000–$60,000\n" +
                    " ", "350 SL", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel southPanel = createSouthPanel(imagePath, button);

        cardLayout04.add(labeltitle, BorderLayout.NORTH);
        cardLayout04.add(description, BorderLayout.CENTER);
        cardLayout04.add(southPanel, BorderLayout.SOUTH);

        cardLayout04.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout04.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout04.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout04;
    }
    //method to create card layout five
    public JPanel createCardLayoutFive() {
        //creating card layout five
        cardLayout05 = createCardPanel();

        //adding components to card layout five
        labeltitle = new JLabel("1998 500 SL",JLabel.CENTER);
        labeltitle.setBounds(50, 10, 300, 30);

        //description
        description = createDescription(" Featured advanced tech like electronically controlled suspension and pop-up roll bars. Called The Great Rebirth.");

        //image icon
         icon = new ImageIcon("src/main/images/1998-sl500.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);

        //button
        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout05, "Advanced roadster with electro-hydraulic roof, V6/V8/V12 options, and modern safety tech." +
                    "\n Price: $15,000–$40,000\n" +
                    " ", "1998-500 SL", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel southPanel = createSouthPanel(imagePath, button);

        //adding components to card layout five
        cardLayout05.add(labeltitle, BorderLayout.NORTH);
        cardLayout05.add(description, BorderLayout.CENTER);
        cardLayout05.add(southPanel, BorderLayout.SOUTH);

        //mouse listener for hover effect
        cardLayout05.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout05.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout05.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout05;
    }

    //method to create card layout six
    public JPanel createCardLayoutSix() {
        //creating card layout six
        cardLayout06 = createCardPanel();

        //adding components to card layout six
        labeltitle = new JLabel("500 SL",JLabel.CENTER);
        labeltitle.setBounds(50, 10, 300, 30);

        description = createDescription("Introduced a retractable hardtop and modernized styling. Dubbed The New Millennium SL.");

        icon = new ImageIcon("src/main/images/SL 500.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);


        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout06, "Sleek hardtop convertible with electronic braking and V6 to V12 engines." +
                    "\n Price: $13,000–$47,000\n" +
                    " ", "500 SL", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel southPanel = createSouthPanel(imagePath, button);

        cardLayout06.add(labeltitle, BorderLayout.NORTH);
        cardLayout06.add(description, BorderLayout.CENTER);
        cardLayout06.add(southPanel, BorderLayout.SOUTH);

        cardLayout06.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout06.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout06.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout06;
    }
    //method to create card layout seven
    public JPanel createCardLayoutSeven() {
        //creating card layout seven
        cardLayout07 = createCardPanel();

        labeltitle = new JLabel("SL-R231",JLabel.CENTER);
        labeltitle.setBounds(50, 10, 300, 30);

        description = createDescription("Focused on lightweight aluminum construction and sharper performance. Received a facelift in 2016.");

        icon = new ImageIcon("src/main/images/SL R231.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);


        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout07, "Sleek hardtop convertible with electronic braking and V6 to V12 engines." +
                    "\n Price: $24,000–$240,000 \n" +
                    " ", "SL R231", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel southPanel = createSouthPanel(imagePath, button);

        cardLayout07.add(labeltitle, BorderLayout.NORTH);
        cardLayout07.add(description, BorderLayout.CENTER);
        cardLayout07.add(southPanel, BorderLayout.SOUTH);

        cardLayout07.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout07.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout07.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout07;
    }

    //method to create card layout eight
    public JPanel createCardLayoutEight() {
        cardLayout08 = createCardPanel();

        labeltitle = new JLabel("AMG SL 63",JLabel.CENTER);
        labeltitle.setBounds(50, 10, 300, 30);

        description = createDescription("High-performance variant with handcrafted AMG engines, sport-tuned suspension, and aggressive styling.");

        icon = new ImageIcon("src/main/images/sl63.jpeg");
        Image scaledImage = icon.getImage().getScaledInstance(180, 120, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);
        imagePath = new JLabel(icon);
//        imagePath.setBounds(50, 100, 300, 200);

        button = new JButton("View More");
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(cardLayout08, "Sleek hardtop convertible with electronic braking and V6 to V12 engines." +
                    "\n Price: $100,000–$200,000+\n" +
                    " ", "SL 63", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel southPanel = createSouthPanel(imagePath, button);

        cardLayout08.add(labeltitle, BorderLayout.NORTH);
        cardLayout08.add(description, BorderLayout.CENTER);
        cardLayout08.add(southPanel, BorderLayout.SOUTH);

        cardLayout08.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardLayout08.setBackground(Color.CYAN);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardLayout08.setBackground(Color.LIGHT_GRAY);
            }
        });

        return cardLayout08;
    }
}
